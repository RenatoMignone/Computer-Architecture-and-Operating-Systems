#include "FreeRTOS.h"
#include "task.h"
#include "uart.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define MAX_PRIORITY (mainTASK_PRIORITY + 7)

void vTaskFunction_startup(void *pvParameters);
void vTaskFunction_1(void *pvParameters);
void vTaskFunction_2(void *pvParameters);
void vTaskFunction_3(void *pvParameters);

int main(int argc, char **argv){

	(void) argc;
	(void) argv;

    	UART_init();
    	
    	int count;

        xTaskCreate(
                vTaskFunction,
                "startup",
                configMINIMAL_STACK_SIZE,
                NULL,
                MAX_PRIORITY,
                NULL
        );

	// Give control to the scheduler
	vTaskStartScheduler();

	// If everything ok should never reach here
    	for( ; ; );
}

/* Task Function */
void vTaskFunction_startup(void *pvParameters) {

        // Avoid warning about unused pvParameters
        (void) pvParameters;
        
        count = 0;
        
        // Round Robin scheduling
        // FreeRTOSConfig.h
        // #define configUSE_PREEMPTION  set to 0

        xTaskCreate(
                vTaskFunction_1,
                "task1",
                configMINIMAL_STACK_SIZE,
                NULL,
                MAX_PRIORITY-2,
                NULL
        );
        
        xTaskCreate(
                vTaskFunction_2,
                "task2",
                configMINIMAL_STACK_SIZE,
                NULL,
                MAX_PRIORITY-2,
                NULL
        );
        
        xTaskCreate(
                vTaskFunction_3,
                "task3",
                configMINIMAL_STACK_SIZE,
                NULL,
                MAX_PRIORITY-1,
                NULL
        );
        
        vTaskDelete(NULL);
    
}

/* Task Function */
void vTaskFunction_1(void *pvParameters) {

        // Avoid warning about unused pvParameters
        (void) pvParameters;

        for (;;) {
        
        	char buffer[50];

                // Delay for 10 ms
                vTaskDelay(pdMS_TO_TICKS(10));
                
                count = count + 5;
                
                sprintf(buffer, "Task 1 - count: %d \n", count);
                UART_printf(buffer);
                
        }
    
}

/* Task Function */
void vTaskFunction_2(void *pvParameters) {

        // Avoid warning about unused pvParameters
        (void) pvParameters;

        for (;;) {

                // Delay for 10 ms
                vTaskDelay(pdMS_TO_TICKS(10));
                
                count = count + 10;
                
                sprintf(buffer, "Task 2 - count: %d \n", count);
                UART_printf(buffer);
                
        }
    
}

/* Task Function */
void vTaskFunction_3(void *pvParameters) {

        // Avoid warning about unused pvParameters
        (void) pvParameters;

        for (;;) {
        
        	// Delay for 1 s
                vTaskDelay(pdMS_TO_TICKS(1000));

                // Task code: print a message
                UART_printf("Task 3\n");
                
                int i = 0;

                for (;;) {
                	// busy waiting
                	i++;
                }
                
        }
    
}
