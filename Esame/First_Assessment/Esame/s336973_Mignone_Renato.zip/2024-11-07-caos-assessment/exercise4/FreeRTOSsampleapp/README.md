# FreeRTOS sample project
This project is an empty FreeRTOS project.

Clone this repository using `--recurse-submodules` 

The application files are in the App folder.