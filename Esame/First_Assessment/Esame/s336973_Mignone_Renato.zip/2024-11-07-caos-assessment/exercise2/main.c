#include <stdint.h>
#include "library.c"

/* This is a function to print strings using UART */
extern void my_printf(const char *s); 
void intToStr(int num, char *str);

int main(void) {
	
    int v = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
 
    int number = 10;
    int res = 0;

    __asm__ volatile(
		    	
		"// store the res in r1"
    
                "ldr r0,=%1 \n"
                "mov r1, #0 //result \n"
                "mov r5, %2 \n"
                
                "sum: \n"
                "mov r3, #0 // index \n"
                "mov r4, #0 \n"

                "sum_loop: \n"
                "cmp r3, r5 \n"
                "beq sum_done \n"
                "ldr r4, [r0, r3, lsl #2] \n"
                "add r3, r3, #1 \n"
                "b sum_loop \n"
                
                "sum_done: \n"
                "mov %0,r1 \n"
                
                : "=r" (res)
                : "r"  (&v), "r" (number)
    
    );

    char buffer[10];
    
    intToStr(res, buffer)

    my_printf(buffer);
    
    return 0;
}
