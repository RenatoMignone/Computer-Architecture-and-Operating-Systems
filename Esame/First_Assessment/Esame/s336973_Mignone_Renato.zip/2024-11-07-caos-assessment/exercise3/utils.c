#include <stdio.h>
#include "utils.h"

void print_message() {
    printf("Hello from utils!\n");
}
