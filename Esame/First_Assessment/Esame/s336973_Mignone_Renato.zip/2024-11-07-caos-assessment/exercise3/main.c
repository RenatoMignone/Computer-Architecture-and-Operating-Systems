#include <stdio.h>
#include "utils.h"

int main() {
    print_message();
    return 0;
}
