#ifndef UTILS_H
#define UTILS_H

void print_message();

#endif
